# Data Schema — bo-register-index

> This document defines every field in `registers.json`. All contributors must follow this schema when adding or updating entries.

---

## Top-Level Structure

```json
{
  "meta": { ... },
  "registers": [ ... ]
}
```

---

## `meta` Object

| Field | Type | Description |
|---|---|---|
| `version` | string | Semantic version of the dataset (e.g. `"1.0.0"`) |
| `last_updated` | string | `YYYY-MM` format |
| `total_countries` | number | Count of entries in `registers` array |
| `maintainer` | string | GitHub username of primary maintainer |
| `description` | string | One-line project description |
| `license` | string | License identifier (MIT) |
| `sources` | array | List of primary data sources used |

---

## `registers` Array — Per-Country Fields

### Identity Fields

| Field | Type | Required | Description |
|---|---|---|---|
| `country` | string | ✅ | Full English country name (e.g. `"United Kingdom"`) |
| `iso_code` | string | ✅ | ISO 3166-1 alpha-2 code (e.g. `"GB"`) |

---

### FATF Membership

| Field | Type | Required | Description |
|---|---|---|---|
| `fatf_member` | boolean | ✅ | Whether the jurisdiction is a direct FATF member |
| `fatf_region` | string | ✅ | `"FATF"` for direct members; name of FSRB for others |
| `fsrb` | string or null | ✅ | Full name of FATF-Style Regional Body if applicable; `null` for FATF members |

---

### Register Identity

| Field | Type | Required | Description |
|---|---|---|---|
| `register_name` | string | ✅ | Official name of the beneficial ownership register |
| `register_status` | enum | ✅ | See valid values below |
| `access_type` | enum | ✅ | See valid values below |
| `public_search_available` | boolean | ✅ | Whether general public can search |

---

### Technical Access

| Field | Type | Required | Description |
|---|---|---|---|
| `api_available` | boolean | ✅ | Whether a structured API exists |
| `api_url` | string or null | ❌ | URL to API documentation if available |
| `direct_url` | string | ✅ | Direct link to the register or official source |

---

### Coverage

| Field | Type | Required | Description |
|---|---|---|---|
| `entity_types_covered` | array | ✅ | List of entity types in scope. Use empty array `[]` if register does not exist. Common values: `companies`, `LLPs`, `partnerships`, `trusts`, `foundations`, `associations` |
| `trusts_covered` | boolean | ✅ | Whether trusts are explicitly in scope |
| `trust_register_note` | string | ✅ | Describe trust register situation even if trusts are not covered |
| `uo_threshold_percent` | number | ✅ | Ownership percentage that triggers BO disclosure. Standard is `25`. Note lower thresholds (India uses `10`) |

---

### Regulatory & Legal

| Field | Type | Required | Description |
|---|---|---|---|
| `legislation` | string | ✅ | Primary legislation enabling the register |
| `implementation_date` | string or null | ✅ | `YYYY-MM-DD` format. `null` if not yet implemented |
| `last_policy_update` | string or null | ✅ | `YYYY-MM-DD` format of most recent material legislative change |
| `eu_member` | boolean | ✅ | Whether jurisdiction is an EU member state |
| `eu_amld_applicable` | boolean | ✅ | Whether EU AML Directives apply (true for EU members and some territories) |

---

### Compliance Ratings

| Field | Type | Required | Description |
|---|---|---|---|
| `fatf_r24_rating` | enum | ✅ | FATF Recommendation 24 compliance rating from latest MER. See valid values below |
| `fatf_mer_year` | number or null | ✅ | Year of most recent FATF Mutual Evaluation Report |
| `fatf_mer_url` | string or null | ✅ | Direct URL to FATF country profile or MER |

---

### Data Quality

| Field | Type | Required | Description |
|---|---|---|---|
| `data_quality_score` | number | ✅ | 1–5 score. See scale below |
| `quality_notes` | string | ✅ | Analyst-written narrative covering known gaps, loopholes, practical access issues, and relevant enforcement context. Minimum 2 sentences. |

---

### Provenance

| Field | Type | Required | Description |
|---|---|---|---|
| `last_verified` | string | ✅ | `YYYY-MM` format. When this entry was last checked for accuracy |
| `data_contributor` | string | ✅ | GitHub username of the person who last verified this entry |

---

## Valid Values

### `register_status`

| Value | Meaning |
|---|---|
| `public` | Anyone can search, free of charge |
| `public_paid` | Anyone can search, but requires payment |
| `restricted` | Only licensed obliged entities (banks, lawyers, notaries) and/or those with demonstrated legitimate interest |
| `government_only` | Accessible only by law enforcement, FIU, or competent authorities |
| `legislation_only` | Legislation passed, but register is not yet operationally live |
| `planned` | Government has publicly committed to a register but no legislation enacted |
| `none` | No register and no active commitment |

---

### `access_type`

| Value | Meaning |
|---|---|
| `free` | No fee for access |
| `paid` | Fee required |
| `restricted` | Access controlled regardless of payment |

---

### `fatf_r24_rating`

| Value | Meaning |
|---|---|
| `compliant` | Full compliance with all FATF R.24 criteria |
| `largely_compliant` | Minor shortcomings only |
| `partially_compliant` | Moderate shortcomings |
| `non_compliant` | Major shortcomings or no effective implementation |
| `not_yet_evaluated` | No MER has assessed R.24 for this jurisdiction |

> Source: Always use the rating from the most recent FATF Mutual Evaluation Report (MER) or Follow-Up Report. Check: https://www.fatf-gafi.org/en/publications/Mutualevaluations/

---

### `data_quality_score` — 1 to 5

| Score | Meaning |
|---|---|
| `5` | Public, free, API available, real-time data, comprehensive BO coverage |
| `4` | Public, free, good coverage, but no API or minor gaps |
| `3` | Restricted access but structured, reliable, and accessible to obliged entities |
| `2` | Limited register — legislation exists but partial implementation, access issues, or data quality concerns |
| `1` | No operational register, planning stage only, or effectively inaccessible |

---

## Notes on Data Quality

- `quality_notes` must be written in plain English, from an analyst's perspective
- Do not copy-paste from official government websites (copyright)
- Include: practical access experience, known loopholes, nominee/trust gaps, enforcement quality, any grey-listing history
- Update `last_verified` whenever you confirm data is still current — even if nothing changed
- If you are unsure about a field, leave a comment in the PR rather than guessing

---

## JSON Formatting Rules

- Use 2-space indentation
- All string values in double quotes
- No trailing commas
- `null` for absent optional fields (not `""` or `false`)
- Arrays use `[]` when empty (not `null`)
- Dates: `"YYYY-MM-DD"` for full dates, `"YYYY-MM"` for month-level

---

*Last updated: 2025-04 | Maintainer: vikas-aml*

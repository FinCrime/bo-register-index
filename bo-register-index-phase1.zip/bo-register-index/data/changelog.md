# Changelog — bo-register-index

All notable changes to this dataset are documented here.

Format: `[Version] — YYYY-MM — Description`

---

## [1.0.0] — 2025-04 — Initial Release

### Added
- Initial dataset with 20 country entries
- Coverage: FATF Core (UK, USA, Germany, France, Netherlands, Canada, Australia, Singapore)
- Coverage: Key offshore jurisdictions (Cayman Islands, BVI, Panama, Jersey)
- Coverage: APAC (India, Hong Kong)
- Coverage: Other FATF members (Switzerland, Japan, South Africa, Brazil)
- Coverage: APAC offshore (Mauritius)
- Full schema with 25 fields per entry
- FATF R.24 compliance ratings sourced from latest available MERs
- Analyst-written quality notes for all 20 entries

### Schema
- Initial schema v1.0 defined in `schema.md`
- Fields: country, iso_code, fatf_member, fatf_region, fsrb, register_name, register_status,
  access_type, public_search_available, api_available, api_url, entity_types_covered,
  trusts_covered, trust_register_note, uo_threshold_percent, direct_url, legislation,
  implementation_date, last_policy_update, fatf_r24_rating, fatf_mer_year, fatf_mer_url,
  eu_member, eu_amld_applicable, data_quality_score, quality_notes, last_verified,
  data_contributor

---

## Upcoming — v1.1.0 (Planned)

- Add 25 additional countries to reach 45 total
- FATF Core additions: Italy, Spain, Belgium, Sweden, Switzerland (update)
- Offshore additions: Bermuda, Guernsey, Isle of Man, Seychelles, Marshall Islands
- APAC additions: Malaysia, South Korea, New Zealand, Indonesia, Philippines, Thailand
- MENA additions: Saudi Arabia, Qatar, Bahrain, Kuwait, Egypt, Jordan
- Africa/Americas: Nigeria, Kenya, Mexico, Argentina

---

## How to Log Changes

When you update an entry or add a new one, add a line here:

```
## [patch] — YYYY-MM — Brief description
### Changed
- [ISO_CODE] Updated register_status from X to Y — reason
- [ISO_CODE] Updated last_verified to YYYY-MM

### Added
- [ISO_CODE] New entry: Country Name
```

---

*Maintained by: vikas-aml | github.com/vikas-aml/bo-register-index*
